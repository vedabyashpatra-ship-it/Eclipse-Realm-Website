// Set this to the deployed Cloudflare Worker URL, with no trailing slash.
// Example: https://eclipse-realm-auth.YOUR-SUBDOMAIN.workers.dev
window.ECLIPSE_CONFIG = {
  API_BASE: 'https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev'
};
