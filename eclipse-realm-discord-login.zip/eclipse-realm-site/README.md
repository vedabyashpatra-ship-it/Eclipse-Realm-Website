# Eclipse Realm — GitHub Pages + Discord Login

This bundle contains the Eclipse Realm static website and a separate Cloudflare Worker for Discord OAuth login. The UI is a prototype; the authentication flow is implemented, but staff roles, guild membership checks, ticket storage, application storage, and admin actions are not implemented yet.

## Part A — Publish the website on GitHub Pages

1. Create a GitHub repository named `eclipse-realm` (a public repository is simplest for GitHub Free Pages; everything in a Pages site is public).
2. Upload `index.html` and `config.js` to the repository root.
3. Open `config.js` and replace `https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev` with the actual Cloudflare Worker URL after Part B.
4. In the repository, open **Settings → Pages** and choose **Deploy from a branch**, branch `main`, folder `/ (root)**. Save.
5. Your website URL will look like `https://YOUR-GITHUB-USERNAME.github.io/eclipse-realm/`. Keep that exact URL for the backend's `FRONTEND_URL` setting. GitHub Pages may take several minutes to publish.

## Part B — Create the Discord OAuth application

1. Open the Discord Developer Portal: https://discord.com/developers/applications
2. Create an application named `Eclipse Realm Website`.
3. Open **OAuth2** and copy the **Client ID**. Keep the **Client Secret** private; never paste it into `index.html`, `config.js`, GitHub, screenshots, or a public chat.
4. Deploy the Worker in Part C to obtain its URL. Add the exact callback URL `https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev/auth/callback` to the OAuth2 **Redirects** list and save.
5. The requested OAuth scope is only `identify`, which provides the user's basic Discord profile. It does not prove they are a member of the Eclipse Realm Discord server.

## Part C — Deploy the authentication backend on Cloudflare Workers

1. Sign in to Cloudflare and open **Workers & Pages**.
2. Create a Worker named `eclipse-realm-auth`.
3. Deploy the contents of `worker/src/index.js` as the Worker entry point. You can paste the file into the Worker editor, or use Wrangler from a computer with Node.js installed:

   ```bash
   cd worker
   npm install -g wrangler
   npx wrangler login
   npx wrangler deploy
   ```

4. In the Worker **Settings → Variables and Secrets**, add these values:
   - `FRONTEND_URL` (variable): exact GitHub Pages URL, e.g. `https://YOUR-GITHUB-USERNAME.github.io/eclipse-realm` (no trailing slash).
   - `REDIRECT_URI` (variable): exact Worker callback URL, e.g. `https://eclipse-realm-auth.YOUR-SUBDOMAIN.workers.dev/auth/callback`.
   - `DISCORD_CLIENT_ID` (variable): the Discord application's Client ID.
   - `DISCORD_CLIENT_SECRET` (**Secret**): the Discord OAuth Client Secret.
   - `SESSION_SECRET` (**Secret**): a long random value, at least 32 random bytes. Generate one locally; do not reuse your Discord secret.
5. Save/deploy the Worker after adding variables and secrets. If you add the values after the first deployment, redeploy so the latest configuration is active.
6. In Discord Developer Portal → OAuth2 → Redirects, add the exact `REDIRECT_URI` from step 4. Save.
7. Update the `API_BASE` in the site's `config.js` to the Worker base URL, without a trailing slash, for example `https://eclipse-realm-auth.YOUR-SUBDOMAIN.workers.dev`. Commit/push that file to GitHub.

## Part D — Test it

1. Open the GitHub Pages website over HTTPS.
2. Press **Login with Discord**, approve the basic profile permission, and wait for the redirect back to the site.
3. Open **Member Dashboard**. It should show your Discord display name, username, and avatar.
4. Press **Log out** to clear the session from that browser tab/session.

## Security notes and limitations

- The Worker uses the OAuth authorization-code flow and validates a random `state` value. The Discord Client Secret and session signing secret stay server-side.
- The browser receives a signed, one-hour session token in the URL fragment; the front end moves it to `sessionStorage` and clears the fragment. It is not a long-lived login and you may need to sign in again after an hour. Avoid running untrusted scripts on the website.
- Do not use client-side checks to protect admin features. Any real admin endpoint must verify staff permissions on the server, and ideally confirm the user's roles in the target Discord guild.
- GitHub Pages is static hosting only. It cannot securely run OAuth client-secret exchanges, maintain private database credentials, or process trusted admin actions itself.
- The current member dashboard's XP, rank, badges, and ticket counts remain demo data. Only the Discord profile identity is live.
- Before adding real applications/reports/tickets, add server-side validation, persistence (such as a database), anti-spam/rate limiting, audit logs, and appropriate privacy disclosures.
