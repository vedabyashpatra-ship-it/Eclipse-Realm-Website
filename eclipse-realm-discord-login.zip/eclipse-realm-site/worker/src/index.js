const encoder = new TextEncoder();
const decoder = new TextDecoder();

function json(data, status = 200, origin = '*') {
  return new Response(JSON.stringify(data), { status, headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    'Vary': 'Origin'
  }});
}
function b64url(bytes) {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
function fromB64url(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  s += '='.repeat((4 - s.length % 4) % 4);
  const raw = atob(s);
  return Uint8Array.from(raw, c => c.charCodeAt(0));
}
async function sign(payload, secret) {
  const head = b64url(encoder.encode(JSON.stringify({ alg: 'HS256', typ: 'JWT' })));
  const body = b64url(encoder.encode(JSON.stringify(payload)));
  const input = `${head}.${body}`;
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, encoder.encode(input));
  return `${input}.${b64url(new Uint8Array(sig))}`;
}
async function verify(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const input = `${parts[0]}.${parts[1]}`;
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const valid = await crypto.subtle.verify('HMAC', key, fromB64url(parts[2]), encoder.encode(input));
  if (!valid) return null;
  const payload = JSON.parse(decoder.decode(fromB64url(parts[1])));
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  return payload;
}
function cookie(request, name) {
  const all = request.headers.get('Cookie') || '';
  const part = all.split(';').map(v => v.trim()).find(v => v.startsWith(`${name}=`));
  return part ? decodeURIComponent(part.slice(name.length + 1)) : null;
}
function redirect(url, headers = {}) { return new Response(null, { status: 302, headers: { Location: url, ...headers } }); }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '';
    const allowedOrigin = env.FRONTEND_URL;
    if (!allowedOrigin || !env.DISCORD_CLIENT_ID || !env.DISCORD_CLIENT_SECRET || !env.SESSION_SECRET || !env.REDIRECT_URI) {
      return json({ error: 'Backend setup incomplete. Configure the Worker secrets and variables.' }, 503, allowedOrigin || '*');
    }
    if (origin && origin !== allowedOrigin) return json({ error: 'Origin not allowed' }, 403, allowedOrigin);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: {
      'Access-Control-Allow-Origin': allowedOrigin, 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Max-Age': '86400', 'Vary': 'Origin'
    }});

    if (url.pathname === '/auth/login' && request.method === 'GET') {
      const state = b64url(crypto.getRandomValues(new Uint8Array(32)));
      const authorize = new URL('https://discord.com/oauth2/authorize');
      authorize.searchParams.set('client_id', env.DISCORD_CLIENT_ID);
      authorize.searchParams.set('response_type', 'code');
      authorize.searchParams.set('redirect_uri', env.REDIRECT_URI);
      authorize.searchParams.set('scope', 'identify');
      authorize.searchParams.set('state', state);
      return redirect(authorize.toString(), { 'Set-Cookie': `er_oauth_state=${encodeURIComponent(state)}; HttpOnly; Secure; SameSite=Lax; Path=/auth/callback; Max-Age=600` });
    }

    if (url.pathname === '/auth/callback' && request.method === 'GET') {
      const state = url.searchParams.get('state');
      const savedState = cookie(request, 'er_oauth_state');
      const code = url.searchParams.get('code');
      const clearState = 'er_oauth_state=; HttpOnly; Secure; SameSite=Lax; Path=/auth/callback; Max-Age=0';
      if (!state || !savedState || state !== savedState || !code || url.searchParams.get('error')) {
        return redirect(`${allowedOrigin}/?auth_error=discord_login_failed`, { 'Set-Cookie': clearState });
      }
      try {
        const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
          method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ client_id: env.DISCORD_CLIENT_ID, client_secret: env.DISCORD_CLIENT_SECRET,
            grant_type: 'authorization_code', code, redirect_uri: env.REDIRECT_URI })
        });
        if (!tokenResponse.ok) throw new Error('Token exchange failed');
        const tokenData = await tokenResponse.json();
        const meResponse = await fetch('https://discord.com/api/v10/users/@me', {
          headers: { Authorization: `Bearer ${tokenData.access_token}` }
        });
        if (!meResponse.ok) throw new Error('Discord profile request failed');
        const user = await meResponse.json();
        const session = await sign({ sub: user.id, username: user.username, global_name: user.global_name || user.username,
          avatar: user.avatar || null, discriminator: user.discriminator || '0', iat: Math.floor(Date.now()/1000),
          exp: Math.floor(Date.now()/1000) + 3600 }, env.SESSION_SECRET);
        // Token is in the URL fragment, which is not sent to the server in HTTP requests.
        return redirect(`${allowedOrigin}/#session=${encodeURIComponent(session)}`, { 'Set-Cookie': clearState, 'Cache-Control': 'no-store' });
      } catch (e) {
        return redirect(`${allowedOrigin}/?auth_error=discord_login_failed`, { 'Set-Cookie': clearState });
      }
    }

    if (url.pathname === '/api/me' && request.method === 'GET') {
      const auth = request.headers.get('Authorization') || '';
      const match = auth.match(/^Bearer\s+(.+)$/i);
      if (!match) return json({ error: 'Not signed in' }, 401, allowedOrigin);
      try {
        const user = await verify(match[1], env.SESSION_SECRET);
        if (!user) return json({ error: 'Session expired. Please sign in again.' }, 401, allowedOrigin);
        return json({ id: user.sub, username: user.username, global_name: user.global_name,
          avatar_url: user.avatar ? `https://cdn.discordapp.com/avatars/${user.sub}/${user.avatar}.png?size=128` : null,
          exp: user.exp }, 200, allowedOrigin);
      } catch { return json({ error: 'Invalid session' }, 401, allowedOrigin); }
    }

    return json({ error: 'Not found' }, 404, allowedOrigin);
  }
};
